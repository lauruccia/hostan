@extends('layouts.app')

@section('page-title')
    {{ __('Service Price List') }}
@endsection

@section('breadcrumb')
    <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">{{ __('Dashboard') }}</a></li>
    <li class="breadcrumb-item active" aria-current="page">{{ __('Service Price List') }}</li>
@endsection

@section('content')
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">{{ __('Service & Maintenance Price Lists') }}</h5>
                <small class="text-muted">{{ __('Define 5 different prices for each service and assign to property owners') }}</small>
            </div>
            <div class="card-body">
                <!-- Add/Edit Form -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h6 class="mb-0">{{ __('Add/Edit Service Price List') }}</h6>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="{{ route('service-price-list.store') }}" id="priceListForm">
                            @csrf
                            <input type="hidden" name="edit_id" id="edit_id" value="">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="form-label">{{ __('Service Type') }} <span class="text-danger">*</span></label>
                                        <select name="service_type_id" id="service_type_id" class="form-control" required>
                                            <option value="">{{ __('Select Service Type') }}</option>
                                            @foreach($serviceTypes as $type)
                                                <option value="{{ $type->id }}">{{ $type->title }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="form-label">{{ __('Property Owner') }} <span class="text-danger">*</span></label>
                                        <select name="owner_id" id="owner_id" class="form-control" required>
                                            <option value="">{{ __('Select Owner') }}</option>
                                            @foreach($owners as $owner)
                                                <option value="{{ $owner->id }}">{{ $owner->first_name }} {{ $owner->last_name }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="form-label">{{ __('Assigned Price List') }} <span class="text-danger">*</span></label>
                                        <select name="assigned_price_list" id="assigned_price_list" class="form-control" required>
                                            <option value="1">Price List 1</option>
                                            <option value="2">Price List 2</option>
                                            <option value="3">Price List 3</option>
                                            <option value="4">Price List 4</option>
                                            <option value="5">Price List 5</option>
                                        </select>
                                        <small class="text-muted">{{ __('Which price list is currently active for this owner') }}</small>
                                    </div>
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-md-2">
                                    <label class="form-label">{{ __('Price List 1') }} <span class="text-danger">*</span></label>
                                    <input type="number" name="price_1" id="price_1" step="0.01" min="0" class="form-control" required>
                                </div>
                                <div class="col-md-2">
                                    <label class="form-label">{{ __('Price List 2') }} <span class="text-danger">*</span></label>
                                    <input type="number" name="price_2" id="price_2" step="0.01" min="0" class="form-control" required>
                                </div>
                                <div class="col-md-2">
                                    <label class="form-label">{{ __('Price List 3') }} <span class="text-danger">*</span></label>
                                    <input type="number" name="price_3" id="price_3" step="0.01" min="0" class="form-control" required>
                                </div>
                                <div class="col-md-2">
                                    <label class="form-label">{{ __('Price List 4') }} <span class="text-danger">*</span></label>
                                    <input type="number" name="price_4" id="price_4" step="0.01" min="0" class="form-control" required>
                                </div>
                                <div class="col-md-2">
                                    <label class="form-label">{{ __('Price List 5') }} <span class="text-danger">*</span></label>
                                    <input type="number" name="price_5" id="price_5" step="0.01" min="0" class="form-control" required>
                                </div>
                                <div class="col-md-2 d-flex align-items-end gap-2">
                                    <button type="submit" class="btn btn-primary w-100">{{ __('Save') }}</button>
                                    <button type="button" class="btn btn-secondary w-100" id="resetForm">{{ __('Reset') }}</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Price List Table -->
                <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>{{ __('Service Type') }}</th>
                                <th>{{ __('Owner') }}</th>
                                <th>{{ __('Price 1') }}</th>
                                <th>{{ __('Price 2') }}</th>
                                <th>{{ __('Price 3') }}</th>
                                <th>{{ __('Price 4') }}</th>
                                <th>{{ __('Price 5') }}</th>
                                <th>{{ __('Assigned') }}</th>
                                <th>{{ __('Actions') }}</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($priceLists as $priceList)
                                <tr>
                                    <td>{{ $priceList->serviceType->title ?? 'N/A' }}</td>
                                    <td>{{ $priceList->owner->first_name ?? '' }} {{ $priceList->owner->last_name ?? '' }}</td>
                                    <td class="{{ $priceList->assigned_price_list == 1 ? 'bg-success bg-opacity-10 fw-bold' : '' }}">
                                        {{ priceFormat($priceList->price_1) }}
                                    </td>
                                    <td class="{{ $priceList->assigned_price_list == 2 ? 'bg-success bg-opacity-10 fw-bold' : '' }}">
                                        {{ priceFormat($priceList->price_2) }}
                                    </td>
                                    <td class="{{ $priceList->assigned_price_list == 3 ? 'bg-success bg-opacity-10 fw-bold' : '' }}">
                                        {{ priceFormat($priceList->price_3) }}
                                    </td>
                                    <td class="{{ $priceList->assigned_price_list == 4 ? 'bg-success bg-opacity-10 fw-bold' : '' }}">
                                        {{ priceFormat($priceList->price_4) }}
                                    </td>
                                    <td class="{{ $priceList->assigned_price_list == 5 ? 'bg-success bg-opacity-10 fw-bold' : '' }}">
                                        {{ priceFormat($priceList->price_5) }}
                                    </td>
                                    <td>
                                        <span class="badge bg-primary">List {{ $priceList->assigned_price_list }}</span>
                                    </td>
                                    <td>
                                        <button class="btn btn-sm btn-secondary edit-price-list" 
                                                data-id="{{ $priceList->id }}"
                                                data-service="{{ $priceList->service_type_id }}"
                                                data-owner="{{ $priceList->owner_id }}"
                                                data-p1="{{ $priceList->price_1 }}"
                                                data-p2="{{ $priceList->price_2 }}"
                                                data-p3="{{ $priceList->price_3 }}"
                                                data-p4="{{ $priceList->price_4 }}"
                                                data-p5="{{ $priceList->price_5 }}"
                                                data-assigned="{{ $priceList->assigned_price_list }}">
                                            <i class="ti ti-edit"></i>
                                        </button>
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="9" class="text-center">{{ __('No price lists found. Please add one above.') }}</td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Edit button click - populate form
    document.querySelectorAll('.edit-price-list').forEach(btn => {
        btn.addEventListener('click', function() {
            document.getElementById('service_type_id').value = this.dataset.service;
            document.getElementById('owner_id').value = this.dataset.owner;
            document.getElementById('price_1').value = this.dataset.p1;
            document.getElementById('price_2').value = this.dataset.p2;
            document.getElementById('price_3').value = this.dataset.p3;
            document.getElementById('price_4').value = this.dataset.p4;
            document.getElementById('price_5').value = this.dataset.p5;
            document.getElementById('assigned_price_list').value = this.dataset.assigned;
            document.getElementById('edit_id').value = this.dataset.id;
            
            // Change form action to update
            const form = document.getElementById('priceListForm');
            const currentAction = form.getAttribute('action');
            if (!currentAction.includes('update')) {
                form.setAttribute('action', '{{ route("service-price-list.update", ":id") }}'.replace(':id', this.dataset.id));
                // Add method override
                if (!form.querySelector('input[name="_method"]')) {
                    const methodInput = document.createElement('input');
                    methodInput.type = 'hidden';
                    methodInput.name = '_method';
                    methodInput.value = 'PUT';
                    form.appendChild(methodInput);
                }
            }
            
            // Scroll to form
            form.scrollIntoView({ behavior: 'smooth', block: 'start' });
        });
    });

    // Reset form button
    document.getElementById('resetForm').addEventListener('click', function() {
        document.getElementById('priceListForm').reset();
        document.getElementById('edit_id').value = '';
        const form = document.getElementById('priceListForm');
        form.setAttribute('action', '{{ route("service-price-list.store") }}');
        const methodInput = form.querySelector('input[name="_method"]');
        if (methodInput) {
            methodInput.remove();
        }
    });
});
</script>
@endsection
