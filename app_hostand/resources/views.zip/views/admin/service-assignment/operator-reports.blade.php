@extends('layouts.app')
@section('page-title')
    {{ __('Operator Reports') }}
@endsection

@section('breadcrumb')
    <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">{{ __('Dashboard') }}</a></li>
    <li class="breadcrumb-item"><a href="{{ route('admin.service-assignment.index') }}">{{ __('Service Assignment') }}</a></li>
    <li class="breadcrumb-item active">{{ __('Operator Reports') }}</li>
@endsection

@section('content')
    <!-- Header Section -->
    <div class="row">
        <div class="col-12">
            <div class="card bg-gradient-success">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col-md-8">
                            <h3 class="mb-1" id="report-title">{{ __('Operator Performance Reports') }}</h3>
                            <p class="text-dark-50 mb-0" id="report-description">
                                <i class="ti ti-report"></i> {{ __('View hourly reports and statistics for operators') }}
                            </p>
                        </div>
                        <div class="col-md-4 text-end">
                            <a href="{{ route('admin.service-assignment.index') }}" class="btn btn-light">
                                <i class="ti ti-arrow-left"></i> {{ __('Back to Service Assignment') }}
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Operator Selector & Date Range Filter -->
    <div class="row mt-4">
        <div class="col-12">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-transparent border-0">
                    <h6 class="mb-0 text-primary">
                        <i class="ti ti-filter"></i> {{ __('Select Operator') }}
                    </h6>
                </div>
                <div class="card-body">
                    <form method="GET" action="{{ route('admin.service-assignment.operator-reports') }}" class="row">
                        <div class="col-md-6 mb-3">
                            <label for="operator_id" class="form-label">{{ __('Select Operator') }}</label>
                            <select class="form-select" id="operator_id" name="operator_id" required>
                                <option value="">{{ __('-- Select Operator --') }}</option>
                                @foreach($allOperators ?? [] as $op)
                                    <option value="{{ $op->id }}" {{ (isset($operatorId) && $operatorId == $op->id) ? 'selected' : '' }}>
                                        {{ $op->first_name }} {{ $op->last_name }}
                                    </option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-md-6 mb-3 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary me-2">
                                <i class="ti ti-search"></i> {{ __('View Reports') }}
                            </button>
                            <a href="{{ route('admin.service-assignment.operator-reports') }}" class="btn btn-outline-secondary">
                                <i class="ti ti-refresh"></i> {{ __('Reset') }}
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    @if(isset($operator) && $operator)
        <!-- Performance Statistics -->
        <div class="row mt-4">
            <div class="col-lg-2 col-md-4 mb-4">
                <div class="card border-0 shadow-sm">
                    <div class="card-body text-center">
                        <div class="avtar bg-primary bg-opacity-10 mx-auto mb-3">
                            <i class="ti ti-list text-primary f-24"></i>
                        </div>
                        <h4 class="text-primary mb-1">{{ $totalAllServices ?? 0 }}</h4>
                        <p class="text-muted mb-0">{{ __('All Services') }}</p>
                    </div>
                </div>
            </div>

            <div class="col-lg-2 col-md-4 mb-4">
                <div class="card border-0 shadow-sm">
                    <div class="card-body text-center">
                        <div class="avtar bg-success bg-opacity-10 mx-auto mb-3">
                            <i class="ti ti-check text-success f-24"></i>
                        </div>
                        <h4 class="text-success mb-1">{{ $totalServices ?? 0 }}</h4>
                        <p class="text-muted mb-0">{{ __('Completed') }}</p>
                    </div>
                </div>
            </div>

            <div class="col-lg-2 col-md-4 mb-4">
                <div class="card border-0 shadow-sm">
                    <div class="card-body text-center">
                        <div class="avtar bg-warning bg-opacity-10 mx-auto mb-3">
                            <i class="ti ti-clock text-warning f-24"></i>
                        </div>
                        <h4 class="text-warning mb-1">{{ $pendingServices ?? 0 }}</h4>
                        <p class="text-muted mb-0">{{ __('Pending') }}</p>
                    </div>
                </div>
            </div>

            <div class="col-lg-2 col-md-4 mb-4">
                <div class="card border-0 shadow-sm">
                    <div class="card-body text-center">
                        <div class="avtar bg-info bg-opacity-10 mx-auto mb-3">
                            <i class="ti ti-tools text-info f-24"></i>
                        </div>
                        <h4 class="text-info mb-1">{{ $inProgressServices ?? 0 }}</h4>
                        <p class="text-muted mb-0">{{ __('In Progress') }}</p>
                    </div>
                </div>
            </div>

            <div class="col-lg-2 col-md-4 mb-4">
                <div class="card border-0 shadow-sm">
                    <div class="card-body text-center">
                        <div class="avtar bg-success bg-opacity-10 mx-auto mb-3">
                            <i class="ti ti-clock text-success f-24"></i>
                        </div>
                        <h4 class="text-success mb-1">{{ number_format($totalHours ?? 0, 1) }}</h4>
                        <p class="text-muted mb-0">{{ __('Total Hours') }}</p>
                    </div>
                </div>
            </div>

            <div class="col-lg-2 col-md-4 mb-4">
                <div class="card border-0 shadow-sm">
                    <div class="card-body text-center">
                        <div class="avtar bg-info bg-opacity-10 mx-auto mb-3">
                            <i class="ti ti-coins text-info f-24"></i>
                        </div>
                        <h4 class="text-info mb-1">{{ number_format($totalAmount ?? 0, 2) }}</h4>
                        <p class="text-muted mb-0">{{ __('Total Amount') }}</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Report Type Tabs -->
        <div class="row mt-4">
            <div class="col-12">
                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-transparent border-0 p-0">
                        <ul class="nav nav-tabs" id="reportTabs" role="tablist">
                            <li class="nav-item" role="presentation">
                                <button class="nav-link active" id="hourly-tab" data-bs-toggle="tab" data-bs-target="#hourly" type="button" role="tab">
                                    <i class="ti ti-clock"></i> {{ __('Hourly Reports') }}
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="daily-tab" data-bs-toggle="tab" data-bs-target="#daily" type="button" role="tab">
                                    <i class="ti ti-calendar"></i> {{ __('Daily Reports') }}
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="monthly-tab" data-bs-toggle="tab" data-bs-target="#monthly" type="button" role="tab">
                                    <i class="ti ti-calendar-month"></i> {{ __('Monthly Reports') }}
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="all-services-tab" data-bs-toggle="tab" data-bs-target="#all-services" type="button" role="tab">
                                    <i class="ti ti-list"></i> {{ __('All Services') }}
                                </button>
                            </li>
                        </ul>
                    </div>
                    <div class="card-body">
                        <div class="tab-content" id="reportTabsContent">
                            <!-- Hourly Reports Tab -->
                            <div class="tab-pane fade show active" id="hourly" role="tabpanel">
                                <h6 class="mb-3 text-primary">{{ __('Hourly Breakdown') }}</h6>
                                @if(isset($servicesByHour) && $servicesByHour->count() > 0)
                                    <div class="table-responsive">
                                        <table class="table table-hover">
                                            <thead class="table-light">
                                                <tr>
                                                    <th>{{ __('Date & Hour') }}</th>
                                                    <th>{{ __('Services') }}</th>
                                                    <th>{{ __('Total Hours') }}</th>
                                                    <th>{{ __('Total Amount') }}</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @foreach($servicesByHour->sortKeys() as $hourKey => $services)
                                                    @php
                                                        $hourHours = $services->sum('hours_worked') ?? 0;
                                                        $hourAmount = $services->sum('amount') ?? 0;
                                                        $hourDate = \Carbon\Carbon::parse($hourKey, 'UTC');
                                                        $settings = settings();
                                                        $timezone = !empty($settings['timezone']) && $settings['timezone'] !== '' ? $settings['timezone'] : 'UTC';
                                                        $hourDate->setTimezone($timezone);
                                                    @endphp
                                                    <tr>
                                                        <td>
                                                            <strong>{{ $hourDate->format('M d, Y') }}</strong><br>
                                                            <small class="text-muted">{{ $hourDate->format('h:i A') }}</small>
                                                        </td>
                                                        <td>
                                                            <span class="badge bg-primary">{{ $services->count() }}</span>
                                                        </td>
                                                        <td>
                                                            <span class="text-success">
                                                                @php
                                                                    if ($hourHours < 1 && $hourHours > 0) {
                                                                        $minutes = round($hourHours * 60);
                                                                        echo $minutes . ' min';
                                                                    } else {
                                                                        echo number_format($hourHours, 1) . 'h';
                                                                    }
                                                                @endphp
                                                            </span>
                                                        </td>
                                                        <td>
                                                            <span class="text-info">${{ number_format($hourAmount, 2) }}</span>
                                                        </td>
                                                    </tr>
                                                @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                @else
                                    <div class="text-center py-4">
                                        <i class="ti ti-clock-off" style="font-size: 3rem; color: #dee2e6;"></i>
                                        <h5 class="mt-3 text-muted">{{ __('No Hourly Data') }}</h5>
                                        <p class="text-muted">{{ __('No completed services found for hourly breakdown.') }}</p>
                                    </div>
                                @endif
                            </div>

                            <!-- Daily Reports Tab -->
                            <div class="tab-pane fade" id="daily" role="tabpanel">
                                <h6 class="mb-3 text-primary">{{ __('Daily Breakdown') }}</h6>
                                @if(isset($servicesByDay) && $servicesByDay->count() > 0)
                                    <div class="table-responsive">
                                        <table class="table table-hover">
                                            <thead class="table-light">
                                                <tr>
                                                    <th>{{ __('Date') }}</th>
                                                    <th>{{ __('All Services') }}</th>
                                                    <th>{{ __('Completed') }}</th>
                                                    <th>{{ __('Total Hours') }}</th>
                                                    <th>{{ __('Total Amount') }}</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @foreach($servicesByDay->sortKeys() as $dayKey => $services)
                                                    @php
                                                        $dayCompleted = $services->where('status', 'completed');
                                                        $dayHours = $dayCompleted->sum('hours_worked') ?? 0;
                                                        $dayAmount = $dayCompleted->sum('amount') ?? 0;
                                                        $dayDate = \Carbon\Carbon::parse($dayKey, 'UTC');
                                                        $settings = settings();
                                                        $timezone = !empty($settings['timezone']) && $settings['timezone'] !== '' ? $settings['timezone'] : 'UTC';
                                                        $dayDate->setTimezone($timezone);
                                                    @endphp
                                                    <tr>
                                                        <td>
                                                            <strong>{{ $dayDate->format('M d, Y') }}</strong><br>
                                                            <small class="text-muted">{{ $dayDate->format('l') }}</small>
                                                        </td>
                                                        <td>
                                                            <span class="badge bg-primary">{{ $services->count() }}</span>
                                                        </td>
                                                        <td>
                                                            <span class="badge bg-success">{{ $dayCompleted->count() }}</span>
                                                        </td>
                                                        <td>
                                                            <span class="text-success">
                                                                @php
                                                                    if ($dayHours < 1 && $dayHours > 0) {
                                                                        $minutes = round($dayHours * 60);
                                                                        echo $minutes . ' min';
                                                                    } else {
                                                                        echo number_format($dayHours, 1) . 'h';
                                                                    }
                                                                @endphp
                                                            </span>
                                                        </td>
                                                        <td>
                                                            <span class="text-info">${{ number_format($dayAmount, 2) }}</span>
                                                        </td>
                                                    </tr>
                                                @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                @else
                                    <div class="text-center py-4">
                                        <i class="ti ti-calendar-off" style="font-size: 3rem; color: #dee2e6;"></i>
                                        <h5 class="mt-3 text-muted">{{ __('No Daily Data') }}</h5>
                                        <p class="text-muted">{{ __('No services found for daily breakdown.') }}</p>
                                    </div>
                                @endif
                            </div>

                            <!-- Monthly Reports Tab -->
                            <div class="tab-pane fade" id="monthly" role="tabpanel">
                                <h6 class="mb-3 text-primary">{{ __('Monthly Breakdown') }}</h6>
                                @if(isset($servicesByMonth) && $servicesByMonth->count() > 0)
                                    <div class="table-responsive">
                                        <table class="table table-hover">
                                            <thead class="table-light">
                                                <tr>
                                                    <th>{{ __('Month') }}</th>
                                                    <th>{{ __('All Services') }}</th>
                                                    <th>{{ __('Completed') }}</th>
                                                    <th>{{ __('Total Hours') }}</th>
                                                    <th>{{ __('Total Amount') }}</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @foreach($servicesByMonth->sortKeys()->reverse() as $monthKey => $services)
                                                    @php
                                                        $monthCompleted = $services->where('status', 'completed');
                                                        $monthHours = $monthCompleted->sum('hours_worked') ?? 0;
                                                        $monthAmount = $monthCompleted->sum('amount') ?? 0;
                                                        $monthDate = \Carbon\Carbon::parse($monthKey . '-01', 'UTC');
                                                    @endphp
                                                    <tr>
                                                        <td>
                                                            <strong>{{ $monthDate->format('F Y') }}</strong>
                                                        </td>
                                                        <td>
                                                            <span class="badge bg-primary">{{ $services->count() }}</span>
                                                        </td>
                                                        <td>
                                                            <span class="badge bg-success">{{ $monthCompleted->count() }}</span>
                                                        </td>
                                                        <td>
                                                            <span class="text-success">
                                                                {{ number_format($monthHours, 1) }}h
                                                            </span>
                                                        </td>
                                                        <td>
                                                            <span class="text-info">${{ number_format($monthAmount, 2) }}</span>
                                                        </td>
                                                    </tr>
                                                @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                @else
                                    <div class="text-center py-4">
                                        <i class="ti ti-calendar-month" style="font-size: 3rem; color: #dee2e6;"></i>
                                        <h5 class="mt-3 text-muted">{{ __('No Monthly Data') }}</h5>
                                        <p class="text-muted">{{ __('No services found for monthly breakdown.') }}</p>
                                    </div>
                                @endif
                            </div>

                            <!-- All Services Tab -->
                            <div class="tab-pane fade" id="all-services" role="tabpanel">
                                <h6 class="mb-3 text-primary">{{ __('All Services List') }}</h6>
                                @if(isset($allServicesUnfiltered) && $allServicesUnfiltered->count() > 0)
                                    <div class="table-responsive">
                                        <table class="table table-hover">
                                            <thead class="table-light">
                                                <tr>
                                                    <th>{{ __('Date') }}</th>
                                                    <th>{{ __('Property') }}</th>
                                                    <th>{{ __('Unit') }}</th>
                                                    <th>{{ __('Service') }}</th>
                                                    <th>{{ __('Status') }}</th>
                                                    <th>{{ __('Hours') }}</th>
                                                    <th>{{ __('Amount') }}</th>
                                                    <th>{{ __('Actions') }}</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @foreach($allServicesUnfiltered as $service)
                                                    <tr>
                                                        <td>
                                                            <small class="text-muted">
                                                                @php
                                                                    $dateDisplay = '-';
                                                                    if (!empty($service->arrival_time)) {
                                                                        $settings = settings();
                                                                        $timezone = !empty($settings['timezone']) && $settings['timezone'] !== '' ? $settings['timezone'] : 'UTC';
                                                                        $dateDisplay = \Carbon\Carbon::parse($service->arrival_time, 'UTC')
                                                                            ->setTimezone($timezone)
                                                                            ->format('M d, Y');
                                                                    }
                                                                @endphp
                                                                {{ $dateDisplay }}
                                                            </small>
                                                        </td>
                                                        <td>
                                                            <strong>{{ $service->properties->name ?? 'N/A' }}</strong>
                                                        </td>
                                                        <td>{{ $service->units->name ?? 'N/A' }}</td>
                                                        <td>
                                                            <span class="badge bg-light-info">
                                                                {{ $service->types->title ?? 'N/A' }}
                                                            </span>
                                                        </td>
                                                        <td>
                                                            @if($service->status == 'pending')
                                                                <span class="badge bg-warning">{{ __('Pending') }}</span>
                                                            @elseif($service->status == 'in_progress')
                                                                <span class="badge bg-info">{{ __('In Progress') }}</span>
                                                            @elseif($service->status == 'completed')
                                                                <span class="badge bg-success">{{ __('Completed') }}</span>
                                                            @endif
                                                        </td>
                                                        <td>
                                                            <span class="text-success">
                                                                @php
                                                                    $hours = $service->hours_worked ?? 0;
                                                                    if ($hours < 1 && $hours > 0) {
                                                                        $minutes = round($hours * 60);
                                                                        echo $minutes . ' min';
                                                                    } else {
                                                                        echo number_format($hours, 1) . 'h';
                                                                    }
                                                                @endphp
                                                            </span>
                                                        </td>
                                                        <td>
                                                            <span class="text-info">
                                                                ${{ number_format($service->amount ?? 0, 2) }}
                                                            </span>
                                                        </td>
                                                        <td>
                                                            <a href="#" class="btn btn-outline-primary btn-sm customModal" 
                                                               data-size="lg" data-title="{{ __('View Service Details') }}" 
                                                               data-url="{{ route('maintenance-request.show', $service->id) }}">
                                                                <i class="ti ti-eye"></i>
                                                            </a>
                                                        </td>
                                                    </tr>
                                                @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                @else
                                    <div class="text-center py-4">
                                        <i class="ti ti-report-off" style="font-size: 3rem; color: #dee2e6;"></i>
                                        <h5 class="mt-3 text-muted">{{ __('No Services Found') }}</h5>
                                        <p class="text-muted">{{ __('No services found in the selected date range for this operator.') }}</p>
                                    </div>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Performance Breakdown Sidebar -->
        <div class="row mt-4">
            <div class="col-lg-12 mb-4">
                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-transparent border-0">
                        <h6 class="mb-0 text-primary">
                            <i class="ti ti-chart-pie"></i> {{ __('Performance Breakdown') }}
                        </h6>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <!-- Services by Property -->
                                <h6 class="text-secondary mb-3">{{ __('Services by Property') }}</h6>
                                @if(isset($servicesByProperty) && $servicesByProperty->count() > 0)
                                    @foreach($servicesByProperty as $propertyId => $services)
                                        @php
                                            $property = $services->first()->properties ?? null;
                                            $propertyHours = $services->sum('hours_worked') ?? 0;
                                            $propertyAmount = $services->sum('amount') ?? 0;
                                        @endphp
                                        @if($property)
                                            <div class="d-flex justify-content-between align-items-center mb-2 p-2 border rounded">
                                                <div>
                                                    <small class="text-muted">{{ $property->name }}</small>
                                                    <br>
                                                    <small class="text-success">{{ $services->count() }} {{ __('services') }}</small>
                                                </div>
                                                <div class="text-end">
                                                    <small class="text-info">{{ number_format($propertyHours, 1) }}h</small>
                                                    <br>
                                                    <small class="text-warning">${{ number_format($propertyAmount, 2) }}</small>
                                                </div>
                                            </div>
                                        @endif
                                    @endforeach
                                @else
                                    <p class="text-muted small">{{ __('No data available.') }}</p>
                                @endif
                            </div>
                            <div class="col-md-6">
                                <!-- Weekly Performance -->
                                <h6 class="text-secondary mb-3">{{ __('Weekly Performance') }}</h6>
                                @if(isset($servicesByWeek) && $servicesByWeek->count() > 0)
                                    @foreach($servicesByWeek as $weekKey => $services)
                                        @php
                                            $weekStart = \Carbon\Carbon::parse($weekKey);
                                            $weekHours = $services->sum('hours_worked') ?? 0;
                                            $weekAmount = $services->sum('amount') ?? 0;
                                        @endphp
                                        <div class="d-flex justify-content-between align-items-center mb-2 p-2 border rounded">
                                            <div>
                                                <small class="text-muted">{{ __('Week of') }} {{ $weekStart->format('M d') }}</small>
                                                <br>
                                                <small class="text-success">{{ $services->count() }} {{ __('services') }}</small>
                                            </div>
                                            <div class="text-end">
                                                <small class="text-info">{{ number_format($weekHours, 1) }}h</small>
                                                <br>
                                                <small class="text-warning">${{ number_format($weekAmount, 2) }}</small>
                                            </div>
                                        </div>
                                    @endforeach
                                @else
                                    <p class="text-muted small">{{ __('No weekly data available.') }}</p>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- All Services List (Old Section - Removed, now in tabs) -->
        <div class="row d-none">
            <div class="col-lg-8 mb-4">
                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-transparent border-0">
                        <h6 class="mb-0 text-primary">
                            <i class="ti ti-list"></i> {{ __('All Services') }} ({{ $startDate }} to {{ $endDate }})
                        </h6>
                    </div>
                    <div class="card-body">
                        @if(isset($allServices) && $allServices->count() > 0)
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead class="table-light">
                                        <tr>
                                            <th>{{ __('Date') }}</th>
                                            <th>{{ __('Property') }}</th>
                                            <th>{{ __('Unit') }}</th>
                                            <th>{{ __('Service') }}</th>
                                            <th>{{ __('Status') }}</th>
                                            <th>{{ __('Hours') }}</th>
                                            <th>{{ __('Amount') }}</th>
                                            <th>{{ __('Actions') }}</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($allServices as $service)
                                            <tr>
                                                <td>
                                                    <small class="text-muted">
                                                        @php
                                                            $dateDisplay = '-';
                                                            if (!empty($service->arrival_time)) {
                                                                $settings = settings();
                                                                $timezone = !empty($settings['timezone']) && $settings['timezone'] !== '' ? $settings['timezone'] : 'UTC';
                                                                $dateDisplay = \Carbon\Carbon::parse($service->arrival_time, 'UTC')
                                                                    ->setTimezone($timezone)
                                                                    ->format('M d, Y');
                                                            }
                                                        @endphp
                                                        {{ $dateDisplay }}
                                                    </small>
                                                </td>
                                                <td>
                                                    <strong>{{ $service->properties->name ?? 'N/A' }}</strong>
                                                </td>
                                                <td>{{ $service->units->name ?? 'N/A' }}</td>
                                                <td>
                                                    <span class="badge bg-light-info">
                                                        {{ $service->types->title ?? 'N/A' }}
                                                    </span>
                                                </td>
                                                <td>
                                                    @if($service->status == 'pending')
                                                        <span class="badge bg-warning">{{ __('Pending') }}</span>
                                                    @elseif($service->status == 'in_progress')
                                                        <span class="badge bg-info">{{ __('In Progress') }}</span>
                                                    @elseif($service->status == 'completed')
                                                        <span class="badge bg-success">{{ __('Completed') }}</span>
                                                    @endif
                                                </td>
                                                <td>
                                                    <span class="text-success">
                                                        @php
                                                            $hours = $service->hours_worked ?? 0;
                                                            if ($hours < 1 && $hours > 0) {
                                                                $minutes = round($hours * 60);
                                                                echo $minutes . ' min';
                                                            } else {
                                                                echo number_format($hours, 1) . 'h';
                                                            }
                                                        @endphp
                                                    </span>
                                                </td>
                                                <td>
                                                    <span class="text-info">
                                                        ${{ number_format($service->amount ?? 0, 2) }}
                                                    </span>
                                                </td>
                                                <td>
                                                    <a href="#" class="btn btn-outline-primary btn-sm customModal" 
                                                       data-size="lg" data-title="{{ __('View Service Details') }}" 
                                                       data-url="{{ route('maintenance-request.show', $service->id) }}">
                                                        <i class="ti ti-eye"></i>
                                                    </a>
                                                </td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        @else
                            <div class="text-center py-4">
                                <i class="ti ti-report-off" style="font-size: 3rem; color: #dee2e6;"></i>
                                <h5 class="mt-3 text-muted">{{ __('No Services Found') }}</h5>
                                <p class="text-muted">{{ __('No services found in the selected date range for this operator.') }}</p>
                            </div>
                        @endif
                    </div>
                </div>
            </div>

            <div class="col-lg-4 mb-4">
                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-transparent border-0">
                        <h6 class="mb-0 text-primary">
                            <i class="ti ti-chart-pie"></i> {{ __('Performance Breakdown') }}
                        </h6>
                    </div>
                    <div class="card-body">
                        <!-- Services by Property -->
                        <h6 class="text-secondary mb-3">{{ __('Services by Property') }}</h6>
                        @if(isset($servicesByProperty) && $servicesByProperty->count() > 0)
                            @foreach($servicesByProperty as $propertyId => $services)
                                @php
                                    $property = $services->first()->properties ?? null;
                                    $propertyHours = $services->sum('hours_worked') ?? 0;
                                    $propertyAmount = $services->sum('amount') ?? 0;
                                @endphp
                                @if($property)
                                    <div class="d-flex justify-content-between align-items-center mb-2 p-2 border rounded">
                                        <div>
                                            <small class="text-muted">{{ $property->name }}</small>
                                            <br>
                                            <small class="text-success">{{ $services->count() }} {{ __('services') }}</small>
                                        </div>
                                        <div class="text-end">
                                            <small class="text-info">{{ number_format($propertyHours, 1) }}h</small>
                                            <br>
                                            <small class="text-warning">${{ number_format($propertyAmount, 2) }}</small>
                                        </div>
                                    </div>
                                @endif
                            @endforeach
                        @else
                            <p class="text-muted small">{{ __('No data available.') }}</p>
                        @endif

                        <hr>

                        <!-- Weekly Performance -->
                        <h6 class="text-secondary mb-3">{{ __('Weekly Performance') }}</h6>
                        @if(isset($servicesByWeek) && $servicesByWeek->count() > 0)
                            @foreach($servicesByWeek as $weekKey => $services)
                                @php
                                    $weekStart = \Carbon\Carbon::parse($weekKey);
                                    $weekHours = $services->sum('hours_worked') ?? 0;
                                    $weekAmount = $services->sum('amount') ?? 0;
                                @endphp
                                <div class="d-flex justify-content-between align-items-center mb-2 p-2 border rounded">
                                    <div>
                                        <small class="text-muted">{{ __('Week of') }} {{ $weekStart->format('M d') }}</small>
                                        <br>
                                        <small class="text-success">{{ $services->count() }} {{ __('services') }}</small>
                                    </div>
                                    <div class="text-end">
                                        <small class="text-info">{{ number_format($weekHours, 1) }}h</small>
                                        <br>
                                        <small class="text-warning">${{ number_format($weekAmount, 2) }}</small>
                                    </div>
                                </div>
                            @endforeach
                        @else
                            <p class="text-muted small">{{ __('No weekly data available.') }}</p>
                        @endif

                        <hr>
                    </div>
                </div>
            </div>
        </div>

        <!-- Performance Charts -->
        @if(isset($servicesByWeek) && $servicesByWeek->count() > 0)
        <div class="row mt-4">
            <div class="col-12">
                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-transparent border-0">
                        <h6 class="mb-0 text-primary">
                            <i class="ti ti-chart-bar"></i> {{ __('Performance Trends') }}
                        </h6>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6 mb-4">
                                <h6 class="text-secondary mb-3">{{ __('Hours Worked Trend') }}</h6>
                                <div class="p-3 border rounded bg-light">
                                    <canvas id="hoursChart" width="400" height="200"></canvas>
                                </div>
                            </div>
                            <div class="col-md-6 mb-4">
                                <h6 class="text-secondary mb-3">{{ __('Services Completed Trend') }}</h6>
                                <div class="p-3 border rounded bg-light">
                                    <canvas id="servicesChart" width="400" height="200"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        @endif
    @else
        <!-- No Operator Selected -->
        <div class="row mt-4">
            <div class="col-12">
                <div class="card border-0 shadow-sm">
                    <div class="card-body text-center py-5">
                        <i class="ti ti-user-off" style="font-size: 4rem; color: #dee2e6;"></i>
                        <h5 class="mt-3 text-muted">{{ __('Select an Operator') }}</h5>
                        <p class="text-muted">{{ __('Please select an operator from the dropdown above to view their performance reports.') }}</p>
                    </div>
                </div>
            </div>
        </div>
    @endif
@endsection

@push('script-page')
@if(isset($servicesByWeek) && $servicesByWeek->count() > 0)
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
@endif
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Auto-submit form when operator is selected
    const operatorSelect = document.getElementById('operator_id');
    const operatorForm = operatorSelect?.closest('form');
    
    if (operatorSelect && operatorForm) {
        operatorSelect.addEventListener('change', function() {
            // Only submit if a value is selected (not empty)
            if (this.value) {
                operatorForm.submit();
            }
        });
    }
    
    // Dynamic header text based on selected tab
    const reportTitle = document.getElementById('report-title');
    const reportDescription = document.getElementById('report-description');
    
    const tabTexts = {
        'hourly': {
            title: '{{ __("Hourly Performance Reports") }}',
            description: '{{ __("View hourly breakdown and statistics for operators") }}',
            icon: 'ti ti-clock'
        },
        'daily': {
            title: '{{ __("Daily Performance Reports") }}',
            description: '{{ __("View daily breakdown and statistics for operators") }}',
            icon: 'ti ti-calendar'
        },
        'monthly': {
            title: '{{ __("Monthly Performance Reports") }}',
            description: '{{ __("View monthly breakdown and statistics for operators") }}',
            icon: 'ti ti-calendar-month'
        },
        'all-services': {
            title: '{{ __("All Services Reports") }}',
            description: '{{ __("View complete service list and details for operators") }}',
            icon: 'ti ti-list'
        }
    };
    
    // Function to update header text
    function updateHeaderText(tabId) {
        const tabData = tabTexts[tabId];
        if (tabData && reportTitle && reportDescription) {
            reportTitle.textContent = tabData.title;
            const iconHtml = `<i class="${tabData.icon}"></i>`;
            reportDescription.innerHTML = iconHtml + ' ' + tabData.description;
        }
    }
    
    // Get all tab buttons
    const tabButtons = document.querySelectorAll('#reportTabs button[data-bs-toggle="tab"]');
    
    // Add click event listeners to tabs
    tabButtons.forEach(button => {
        button.addEventListener('shown.bs.tab', function(event) {
            const targetId = event.target.getAttribute('data-bs-target');
            let tabId = '';
            
            if (targetId === '#hourly') {
                tabId = 'hourly';
            } else if (targetId === '#daily') {
                tabId = 'daily';
            } else if (targetId === '#monthly') {
                tabId = 'monthly';
            } else if (targetId === '#all-services') {
                tabId = 'all-services';
            }
            
            if (tabId) {
                updateHeaderText(tabId);
            }
        });
    });
    
    // Set initial text based on active tab
    const activeTab = document.querySelector('#reportTabs button.active');
    if (activeTab) {
        const targetId = activeTab.getAttribute('data-bs-target');
        let tabId = '';
        
        if (targetId === '#hourly') {
            tabId = 'hourly';
        } else if (targetId === '#daily') {
            tabId = 'daily';
        } else if (targetId === '#monthly') {
            tabId = 'monthly';
        } else if (targetId === '#all-services') {
            tabId = 'all-services';
        }
        
        if (tabId) {
            updateHeaderText(tabId);
        }
    }

    @if(isset($servicesByWeek) && $servicesByWeek->count() > 0)
    // Charts code
    // Hours Worked Chart
    const hoursCtx = document.getElementById('hoursChart');
    if (hoursCtx) {
        new Chart(hoursCtx.getContext('2d'), {
            type: 'line',
            data: {
                labels: @json($servicesByWeek->keys()->take(4)->map(function($week) {
                    return \Carbon\Carbon::parse($week)->format('M d');
                })),
                datasets: [{
                    label: '{{ __("Hours Worked") }}',
                    data: @json($servicesByWeek->take(4)->map(function($services) {
                        return $services->sum('hours_worked') ?? 0;
                    })),
                    borderColor: '#28a745',
                    backgroundColor: 'rgba(40, 167, 69, 0.1)',
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }

    // Services Completed Chart
    const servicesCtx = document.getElementById('servicesChart');
    if (servicesCtx) {
        new Chart(servicesCtx.getContext('2d'), {
            type: 'bar',
            data: {
                labels: @json($servicesByWeek->keys()->take(4)->map(function($week) {
                    return \Carbon\Carbon::parse($week)->format('M d');
                })),
                datasets: [{
                    label: '{{ __("Services Completed") }}',
                    data: @json($servicesByWeek->take(4)->map(function($services) {
                        return $services->count();
                    })),
                    backgroundColor: '#17a2b8',
                    borderColor: '#17a2b8',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }
    @endif
});
</script>
@endpush

